function selecionaTexto() {
    document.getElementById("cpf").focus();
}

selecionaTexto();
 